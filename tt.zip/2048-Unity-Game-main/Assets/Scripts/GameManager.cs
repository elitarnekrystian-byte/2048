using System.Collections;
using TMPro;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public TileBoard tileBoard; // Reference to the TileBoard script
    public CanvasGroup gameOver;
    public TextMeshProUGUI scoreText; // Reference to the score text UI element
    public TextMeshProUGUI bestText; // Reference to the best score text UI element

    private int score; // Current score

    private void Start()
    {
        NewGame();   
    }

    public void NewGame()
    {
        SetScore(0); // Reset the score to 0
        bestText.text = LoadBestScore().ToString(); // Load and display the best score

        gameOver.alpha = 0f; // Reset the game over canvas to fully transparent
        gameOver.interactable = false; // Disable interaction with the game over canvas

        tileBoard.ClearBoard(); // Clear the board
        tileBoard.CreateTile(); // Create the first tile
        tileBoard.CreateTile(); // Create the second tile
        tileBoard.enabled = true; // Enable the TileBoard script to start accepting input
    }

    public void GameOver()
    {
        tileBoard.enabled = false; // Disable the TileBoard script to stop accepting input

        gameOver.interactable = true; // Enable interaction with the game over canvas

        StartCoroutine(Fade(gameOver, 1f, 1f)); // Fade out the board
    }

    private IEnumerator Fade(CanvasGroup canvasGroup, float toAlpha, float delay)
    {
        yield return new WaitForSeconds(delay); // Wait for the specified delay

        float elapsedTime = 0f; // Start the fade timer 
        float duration = 0.5f; // Duration of the fade animation
        float startAlpha = canvasGroup.alpha; // Get the starting alpha value

        while (elapsedTime < duration)
        {
            elapsedTime += Time.deltaTime; // Increment the elapsed time
            canvasGroup.alpha = Mathf.Lerp(startAlpha, toAlpha, elapsedTime / duration); // Interpolate the alpha value
            yield return null; // Wait for the next frame
        }

        canvasGroup.alpha = toAlpha; // Ensure the final alpha value is set
    }

    private void SetScore(int score)
    {
        this.score = score;

        scoreText.text = score.ToString(); // Update the score text UI element

        SaveBestScore(); // Save the best score if the current score is higher
    }

    private void SaveBestScore()
    {
        int bestScore = LoadBestScore(); // Load the best score from storage
        if (score > bestScore)
        {
            PlayerPrefs.SetInt("BestScore", score); // Save the new best score
        }
    }

    private int LoadBestScore()
    {
        // Load the best score from PlayerPrefs or any other storage
        return PlayerPrefs.GetInt("BestScore", 0);
    }

    public void UpdateScore(int points)
    {
        SetScore(score + points); // Update the score with the given points
    }
}
