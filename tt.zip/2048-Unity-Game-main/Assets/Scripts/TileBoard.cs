using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileBoard : MonoBehaviour
{
    public GameManager gameManager; // Reference to the GameManager script

    private TileGrid grid;

    public Tile tilePrefab;
    private List<Tile> tiles;

    public TileState[] tileStates;

    private bool waiting; // Flag to check if the tile is currently moving

    private void Awake()
    {
        grid = GetComponentInChildren<TileGrid>();
        tiles = new List<Tile>(16);
    }

    public void CreateTile()
    {
        Tile newTile = Instantiate(tilePrefab, grid.transform);
        newTile.SetState(tileStates[0], 2);
        TileCell cell = grid.GetRandomEmptyCell();
        newTile.Spawn(cell);
        tiles.Add(newTile);
    }

    public void ClearBoard()
    {
        foreach (var cell in grid.cells)
            cell.tile = null; // Clear all tile references in the grid cells

        foreach (Tile tile in tiles)
        {
            Destroy(tile.gameObject);
        }
        tiles.Clear();
    }

    private void Update()
    {
        if (waiting)
        {
            return; // If a tile is currently moving, ignore input
        }

        if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
        {
            Debug.Log("Moving Up");
            MoveTiles(Vector2Int.up, 0, 1, 1, 1);
        }
        else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
        {
            Debug.Log("Moving Down");
            MoveTiles(Vector2Int.down, 0, 1, grid.height-2 , -1);
        }
        else if (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow))
        {
            Debug.Log("Moving Left");
            MoveTiles(Vector2Int.left, 1, 1, 0, 1);
        }
        else if (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow))
        {
            Debug.Log("Moving Right");
            MoveTiles(Vector2Int.right, grid.width-2, -1, 0,1 );
        }
    }

    private void MoveTiles(Vector2Int direction, int startX, int incrementX, int startY, int incrementY)
    {
        bool changed = false;
        for (int x = startX; x < grid.width && x >= 0; x += incrementX)
        {
            for (int y = startY; y < grid.height && y >= 0; y += incrementY)
            {
                TileCell cell = grid.GetCell(x, y);
                if (cell.occupied)
                {
                    changed |= MoveTile(cell.tile, direction);
                }

            }
        }

        if (changed)
        {
            StartCoroutine(WaitForTileMovement()); // Wait for the tile movement to complete
        }
    }

    private bool MoveTile(Tile tile, Vector2Int direction)
    {
        TileCell newCell = null;
        TileCell adjacent= grid.GetAdjacentCell(tile.cell, direction);

        while(adjacent != null)
        {
            if (adjacent.occupied)
            {
                if (CanMerge(tile, adjacent.tile))
                {
                    Merge(tile, adjacent.tile); // Merge the tiles
                    return true; // Tile merged successfully
                }

                break;
            }

            newCell = adjacent;
            adjacent = grid.GetAdjacentCell(adjacent, direction);
        }

        if (newCell != null)
        {
            tile.MoveTo(newCell);
            return true; // Tile moved successfully
        }
        return false; // No valid move found
    }

    private IEnumerator WaitForTileMovement()
    {
        waiting = true; // Set the flag to indicate a tile is moving
        yield return new WaitForSeconds(0.1f); // Wait for the tile movement animation to complete
        waiting = false; // Reset the flag after the movement is done

        foreach(var tile in tiles)
        {
            tile.locked = false; // Unlock all tiles after movement
        }

        if (tiles.Count < grid.size) 
        {
            CreateTile(); // Create a new tile if there is space
        }

        if (CheckForGameOver())
        {
            gameManager.GameOver(); // Notify the GameManager if the game is over
        }
        else
        {
            //gameManager.UpdateScore(); // Update the score if the game is still ongoing
        }
    }

    private bool CanMerge(Tile a, Tile b)
    {
        return a.number == b.number && !b.locked;
    }

    private void Merge(Tile a, Tile b)
    {
        tiles.Remove(a); // Remove the merged tile from the list
        a.Merge(b.cell); // Merge the tile into the new cell

        int index = Mathf.Clamp(IndexOf(b.state)+1, 0 ,tileStates.Length-1);
        int newNumber = b.number * 2;

        b.SetState(tileStates[index], newNumber); // Update the state and number of the merged tilez

        gameManager.UpdateScore(newNumber); // Update the score in the GameManager
    }

    private int IndexOf(TileState state)
    {
        for (int i = 0; i < tileStates.Length; i++)
        {
            if (tileStates[i] == state)
            {
                return i;
            }
        }
        return -1; // Not found
    }

    private bool CheckForGameOver()
    {
        if (tiles.Count != grid.size)
        {
            return false; // Game is not over if there are still empty cells
        }

        foreach (Tile tile in tiles)
        {
            TileCell adjacent = grid.GetAdjacentCell(tile.cell, Vector2Int.up);
            if (adjacent != null && adjacent.occupied && CanMerge(tile, adjacent.tile))
            {
                return false; // Game is not over if there is a valid merge
            }
            adjacent = grid.GetAdjacentCell(tile.cell, Vector2Int.down);
            if (adjacent != null && adjacent.occupied && CanMerge(tile, adjacent.tile))
            {
                return false; // Game is not over if there is a valid merge
            }
            adjacent = grid.GetAdjacentCell(tile.cell, Vector2Int.left);
            if (adjacent != null && adjacent.occupied && CanMerge(tile, adjacent.tile))
            {
                return false; // Game is not over if there is a valid merge
            }
            adjacent = grid.GetAdjacentCell(tile.cell, Vector2Int.right);
            if (adjacent != null && adjacent.occupied && CanMerge(tile, adjacent.tile))
            {
                return false; // Game is not over if there is a valid merge
            }
        }

        return true; // Game is over if no valid moves or merges are available
    }
}
