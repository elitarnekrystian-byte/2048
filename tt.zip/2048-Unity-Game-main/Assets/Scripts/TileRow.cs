using UnityEngine;

public class TileRow : MonoBehaviour
{
    public TileCell[] cells { get; private set; }

    private void Awake()
    {
        // Initialize the cells array with the TileCell components found in the children of this GameObject
        cells = GetComponentsInChildren<TileCell>();
    }
}
